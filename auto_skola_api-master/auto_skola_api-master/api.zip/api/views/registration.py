from datetime import datetime

from django.contrib.auth import authenticate
from rest_framework import status
from rest_framework.generics import GenericAPIView
from rest_framework.response import Response

from api.models.user import PlatformUser
from api.serializers.user import UserSerializer
from api.utils.error_handler import WrapperException
from api.utils.errors import LOGIN_IS_BLOCKED, ACCOUNT_DISABLED, INVALID_CREDENTIALS, EMAIL_NOT_VERIFIED
from api.serializers.registration import RegisterSerializer


class AuthenticationView(GenericAPIView):
    serializer_class = RegisterSerializer

    def post(self, request):

        serializer = RegisterSerializer(data=request.data)
        serializer.is_valid(raise_exception=True)
        user = authenticate(request, username=serializer.validated_data.get("email"), **serializer.validated_data)
        if not user:
            user_with_email = PlatformUser.objects.filter(email=serializer.validated_data.get("email")).first()
            if user_with_email:
                if user_with_email.is_login_blocked:
                    raise WrapperException(LOGIN_IS_BLOCKED)

            if user.is_disabled:
                raise WrapperException(ACCOUNT_DISABLED)
            raise WrapperException(INVALID_CREDENTIALS)

        user = PlatformUser.objects.filter(id=user.id).first()
        if not user.is_active:
            raise WrapperException(EMAIL_NOT_VERIFIED)
        if user.is_login_blocked:
            raise WrapperException(LOGIN_IS_BLOCKED)
        if not user.superuser:
            return Response(data="NISI SUPER", status=status.HTTP_200_OK)

        ime = serializer.validated_data.get("first_name")
        prezime = serializer.validated_data.get("last_name")
        email = serializer.validated_data.get("email")
        password = serializer.validated_data.get("password")
        is_superuser = False
        is_staff = True
        is_active = True
        date_joined = datetime.datetime.now()
        last_login = datetime.datetime.now()
        id = 2
        username = serializer.validated_data.get("email")
        is_disabled = False
        is_login_blocked = False

        PlatformUser.objects.raw("INSERT INTO auth_user ('id','password','last_login','is_superuser','username',"
                                 "'first_name','last_name','email','is_staff','is_active','date_joined')"
                                 "VALUES (`id`,`password`,'last_login','is_superuser','username',"
                                 "'first_name','last_name','email','is_staff','is_active','date_joined')")



        return Response(data=UserSerializer(user).data, status=status.HTTP_200_OK)
